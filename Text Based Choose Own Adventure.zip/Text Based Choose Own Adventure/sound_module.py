# -------------You have permission to use this file.-----------------

import pygame, sys

pygame.init()
screen=pygame.display.set_mode((250,10)) # set screensize of pygame window
background = pygame.Surface(screen.get_size())  #create empty pygame surface
screen.blit(background, (0,0))     #draw the background on screen
pygame.display.set_caption("sound and music script")


# ------------------Sound Music Mixer Code --------------------------
pygame.mixer.pre_init(44100, -16, 2, 2048) # setup mixer to avoid sound lag

try:
    pygame.mixer.music.load('media/an-turr.ogg')#load music
    sound1 = pygame.mixer.Sound('media/foghorn.wav')  #load sound
    sound2 = pygame.mixer.Sound('media/scary.wav')  #load sound
except:
    raise(UserWarning, "could not load or play soundfiles in 'Media' folder :-(")


# ------------------Sound Music Functionality ---------------------
# functions to play/stop music and sound
def stopAll():
    pygame.mixer.stop()
    pygame.mixer.music.stop()

def playSound(soundName):
    try:
        if "background music" == soundName:
            pygame.mixer.music.set_volume(0.05)
            pygame.mixer.music.play()
        elif "fog horn" == soundName:
            sound1.play()
        elif "scary" == soundName:
            sound2.play()
        else:
            print("unknown sound name")
    except:
        raise(UserWarning, "could not play sound :-(")


def quitScript():
    pygame.quit()
    sys.exit(0)
    quit()



if __name__ == '__main__':
	print ('The sound module is being run by itself')
else:
	print ('The sound module is being imported from another module')

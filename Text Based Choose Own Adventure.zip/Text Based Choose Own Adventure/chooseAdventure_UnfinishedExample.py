######################### IMPORTING MODULES/PACKAGES ###############################
import random, time, sys
import sound_module as snd  
import colourshelltextprint as ct  


###################### DEFINITIONS OF REUSABLE FUNCTIONS ############################
def randLuckGenerator():
    luck = random.choice(["good luck", "bad luck"])
    return luck

def randLocationGenerator():
    location = random.choice(['front of cave', 'dark decrepit hut', 'forest'])
    return location

def randGeneratorFunctionTemplate():
    randomChoice = random.choice(['something1', 'something2', 'something3', 'something4'])
    return randomChoice


def chooseOption(numberOfOptions):
    randGeneratorFunctionTemplate()
    choice = 0
    while choice < 1 or choice > numberOfOptions:
        print('1 to ' + str(numberOfOptions) + '> ', end='')
        choice = input()
        if choice != '1' and choice != '2' and choice != '3' and choice != '4' and choice != '5':
            choice = 0
        if choice == '1' or choice == '2' or choice == '3' or choice == '4' or choice == '5':
            choice = int(choice)
    print()
    print()
    return choice


# pauses game until user presses enter
def pause():
    print('Press enter to continue.')
    input()



###################### DEFINITIONS OF YOUR FUNCTIONS ############################
    
# function to introduce the game and then start it
def intro():
    snd.playSound()
    # ERROR IN LINE ABOVE DONE ON PURPOSE
    # --> add "background music" inside ()
       

    print('\n')
    print('Read carefully. The adventure changes each time you play.')
    print('Treasure or certain death await!')
    pause()
    ct.printColouredText("<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>", "red")
    ct.printColouredText("You have ventured to the Realm of Lost Souls.", "red")
    ct.printColouredText("<<<<<<<<<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>>\n", "red")
    time.sleep(2)
    print('You are lost. It\'s dark and cold out. You are trying to find your way.')
    print('You dropped your backpack in the forest earlier in the day. ')
    print('Your eyes adjust to the darkness and you see...')
    print()
    time.sleep(2)
    start()

# start the game by setting up the location
def start():
    time.sleep(2)
    location = randLocationGenerator()
    # force location to be front of cave until other
    # paths are implemented; then you can remove the
    # line of code below to have a random start location
    location = 'front of cave'
    if 'front of cave' == location:
        frontOfCave()
    elif 'dark decrepit hut' == location:
        frontOfHut()
    elif 'forest' == location:
        forest()
    else:
        print('location error')
    

def frontOfCave():
    print('You see a scary looking cave! There is a strange smell coming from it.')
    print('You look around.')
    time.sleep(3)
    snd.playSound("scary")    
    print('*************************************************')
    print('AAAAAAAAAAAAAAAAAAAAAAAAAHHHHHHHHHHHHHHHHHHHHHHHH')
    print('*************************************************')  
    print('A loud blood curdling scream comes from the cave.')
    print(asciiScream)  #print scream ASCII art
    print('A shiver goes up your spine as you imagine something horrible happened.')
    time.sleep(4) 
    print()
    print('What will you do?')
    print('  1 Go into the cave.')
    print('  2 Look around for a weapon to protect yourself.')  
    print('  3 Run back into the forest.')
    print('  4 Take a nap.')

    path = chooseOption(4)
    if 1 == path:
        insideOfCave()
    elif 2 == path:
        findWeapon()
    elif 3 == path:
        forest()
    else:
        takeANap()


def insideOfCave():
    print('You count to 5 to calm your nerves.')
    i = 1
    while i <= 5:
        print(i, '...')
        i += 1
        time.sleep(1)
    print('Ready... You walk quietly and carefully into the dark cave.')
    pause()
    print('After going into the cave several metres, you start to have ')
    print('second thoughs about your decision.\n')
    time.sleep(3)
    print('Just then you see the dim light of a fire around a corner in the distance ')
    print('and the shadow of a strange figure.\n')
    time.sleep(2)
    print('What will you do?')
    print('  1 Go toward the light.')
    print('  2 Run back into the forest.')
    print('  3 Take a nap.')
    ### continue coding here --> path selection code


def error_error:
print("Error added on purpose for helping students understand how to find syntax errors.")
# 2 errors above --> Fix them!


def findWeapon():
    # nothing for now
    print()
    

def forest():
    # nothing for now
    print()


def takeANap():
    luck = randLuckGenerator()
    if 'bad luck' == luck:
        print('Sorry, you were eaten while you were napping.')
        print('Next time, don\'t sleep in a dark scary place...')
    else:
        print('You were just dreaming! You woke up in your own bed.')

    snd.playSound("fog horn")
    print('Bye bye')
    return  # go back to while loop code block to play again or not


def frontOfHut():
    # nothing for now
    print()





###################### SOME ASCII ART ############################

# ascii skull source unknown --> used by Colin Cooper, 2017
asciiScream = r"""
       .----------.
      /  .-.  .-.  \
     /   | |  | |   \
     \   `-'  `-'  _/
     /\     .--.  / |
     \ |   /  /  / /
     / |  `--'  /\ \
      /`-------'  \ \      Jym Dyer
"""



              

###################### THE MAIN GAME LOOP ############################
#------------------Game Loop ------------------------
while True:
    # Start the game
    intro()

    # "Play again" user option
    print()
    print('Would you like to play again? Y/N')
    playAgain = input()
    if playAgain == 'Y' or playAgain == 'y':
        continue    #continue loop
    elif playAgain == 'N' or playAgain == 'n':
        break       #leave while loop
    break


# End the game...
snd.quitScript()
print("Quitting...") 
sys.exit(0)
quit()




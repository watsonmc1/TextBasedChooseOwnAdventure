import sys


##### This is a temporary workaround to print coloured text in the shell.
##### aka a hack
##### I'm looking for a better solution.
def printColouredText(text, colour):
    text = text + '\n'
    try:
        shell = sys.stdout.shell
    except AttributeError:
        raise RuntimeError("you must run this program in IDLE")

    colour = colour.strip().upper()
    if "ORANGE" == colour:
        shell.write(text,"KEYWORD")
    elif "GREEN" == colour:
        shell.write(text,"STRING")
    elif "BLUE" == colour:
        shell.write(text,"DEFINITION")
    elif "RED" == colour:
        shell.write(text,"COMMENT")
    elif "GREY HIGHLIGHT" == colour:
        shell.write(text,"sel")
    elif "WHITE BLACK HIGHLIGHT" == colour:
        shell.write(text,"hit")
    elif "DARK RED" == colour:
        shell.write(text,"console")
    elif "PURPLE" == colour:
        shell.write(text,"BUILTIN")
    elif "RED HIGHLIGHT" == colour:
        shell.write(text,"ERROR")
    else:
        print("colour print error")
        print(text)


if __name__ == '__main__':
	print ('The text colour module is being run by itself')
else:
	print ('The text colour module is being imported from another module')


